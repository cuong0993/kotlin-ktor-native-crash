var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "15750",
        "ok": "2459",
        "ko": "13291"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "527",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "30082",
        "ok": "19788",
        "ko": "30082"
    },
    "meanResponseTime": {
        "total": "19903",
        "ok": "8635",
        "ko": "21988"
    },
    "standardDeviation": {
        "total": "12822",
        "ok": "3666",
        "ko": "12825"
    },
    "percentiles1": {
        "total": "30004",
        "ok": "7763",
        "ko": "30007"
    },
    "percentiles2": {
        "total": "30012",
        "ok": "10427",
        "ko": "30013"
    },
    "percentiles3": {
        "total": "30016",
        "ok": "16153",
        "ko": "30016"
    },
    "percentiles4": {
        "total": "30017",
        "ok": "18631",
        "ko": "30017"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 8,
    "percentage": 0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2449,
    "percentage": 16
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 13291,
    "percentage": 84
},
    "meanNumberOfRequestsPerSecond": {
        "total": "47.727",
        "ok": "7.452",
        "ko": "40.276"
    }
},
contents: {
"req_image-requested-a5992": {
        type: "REQUEST",
        name: "Image requested",
path: "Image requested",
pathFormatted: "req_image-requested-a5992",
stats: {
    "name": "Image requested",
    "numberOfRequests": {
        "total": "15750",
        "ok": "2459",
        "ko": "13291"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "527",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "30082",
        "ok": "19788",
        "ko": "30082"
    },
    "meanResponseTime": {
        "total": "19903",
        "ok": "8635",
        "ko": "21988"
    },
    "standardDeviation": {
        "total": "12822",
        "ok": "3666",
        "ko": "12825"
    },
    "percentiles1": {
        "total": "30004",
        "ok": "7763",
        "ko": "30007"
    },
    "percentiles2": {
        "total": "30012",
        "ok": "10427",
        "ko": "30013"
    },
    "percentiles3": {
        "total": "30016",
        "ok": "16149",
        "ko": "30016"
    },
    "percentiles4": {
        "total": "30017",
        "ok": "18631",
        "ko": "30017"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 8,
    "percentage": 0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2449,
    "percentage": 16
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 13291,
    "percentage": 84
},
    "meanNumberOfRequestsPerSecond": {
        "total": "47.727",
        "ok": "7.452",
        "ko": "40.276"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
